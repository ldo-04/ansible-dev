# Ansible Collection - lina.myfirstcollection

Documentation for the collection.
